QEMU build for X86 machines with linux kernel, such as Android X86 or other Linux distributions, using shared libraries.

This version is build with:
Graphic support of sdl, gtk and vnc;
Audio drive of sdl, oss, alsa.

LICENCE:
No commercial use, personal or reasearch use only.
In general, file 'qemu-system-i386' and direcotry 'pc-bios' are build with original QEMU source codes of version 2.1.1， follow GPL v2 licence of QEMU, and directory 'lib' contains libraries which are copied from official Ubuntu 14.04 i386 desktop is also build under GPL licence.

Contact: felonwan@gmail.com
