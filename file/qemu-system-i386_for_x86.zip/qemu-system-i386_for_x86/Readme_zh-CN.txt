本软件是X86版的QEMU虚拟机。
适用于使用Linux内核的CPU为X86的机器，比如Android X86或其它Linux发行版。

此版本支持使用sdl、gtk或vnc图形界面，包含sdl、oss、alsa声音驱动。

许可证：
只用于个人使用和研究用途，不得用于商业用途。
总体来说，“qemu-system-i386”和“pc-bios”基于QEMU官方下载的源码2.1.1版本构建，遵守QEMU的GPL协议，lib目录下的库文件都是从Ubuntu 14.04 i386官方桌面版本中复制过来的，也基于GPL协议。

Email: felonwan@gmail.com
